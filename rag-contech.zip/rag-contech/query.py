"""
Interroge le RAG : récupère les chunks pertinents dans ChromaDB
puis demande à Claude de répondre en se basant dessus.

Usage :
    python query.py "Quelle est la différence entre Buildertrend et Procore pour l'estimation ?"
"""

import sys

import chromadb
from anthropic import Anthropic
from sentence_transformers import SentenceTransformer

import config


def retrieve(question: str, model: SentenceTransformer, collection, top_k: int):
    query_embedding = model.encode([question]).tolist()
    results = collection.query(query_embeddings=query_embedding, n_results=top_k)
    chunks = results["documents"][0]
    metadatas = results["metadatas"][0]
    return list(zip(chunks, metadatas))


def build_context(retrieved: list[tuple[str, dict]]) -> str:
    parts = []
    for text, meta in retrieved:
        parts.append(f"[Source: {meta['source']}]\n{text}")
    return "\n\n---\n\n".join(parts)


def ask_claude(client: Anthropic, question: str, context: str) -> str:
    message = client.messages.create(
        model=config.CLAUDE_MODEL,
        max_tokens=1500,
        system=config.SYSTEM_PROMPT,
        messages=[
            {
                "role": "user",
                "content": f"Contexte extrait des documents :\n\n{context}\n\n---\n\nQuestion : {question}",
            }
        ],
    )
    return "".join(block.text for block in message.content if block.type == "text")


def main():
    if len(sys.argv) < 2:
        print('Usage : python query.py "ta question ici"')
        return
    question = " ".join(sys.argv[1:])

    if not config.ANTHROPIC_API_KEY:
        print("⚠️  Définis la variable d'environnement ANTHROPIC_API_KEY avant de lancer ce script.")
        return

    print("Chargement du modèle d'embeddings...")
    model = SentenceTransformer(config.EMBEDDING_MODEL)

    client_db = chromadb.PersistentClient(path=str(config.DB_DIR))
    try:
        collection = client_db.get_collection(config.COLLECTION_NAME)
    except Exception:
        print("Aucune collection trouvée. Lance d'abord : python ingest.py")
        return

    print(f"Recherche des {config.TOP_K} passages les plus pertinents...")
    retrieved = retrieve(question, model, collection, config.TOP_K)

    print("Sources utilisées :", ", ".join(sorted({m["source"] for _, m in retrieved})))
    context = build_context(retrieved)

    print("\nGénération de la réponse...\n")
    client = Anthropic(api_key=config.ANTHROPIC_API_KEY)
    answer = ask_claude(client, question, context)

    print("=" * 60)
    print(answer)
    print("=" * 60)


if __name__ == "__main__":
    main()
