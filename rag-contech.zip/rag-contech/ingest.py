"""
Ingestion : lit tous les documents du dossier data/ (PDF, TXT, MD),
les découpe en chunks, calcule leurs embeddings, et les stocke dans ChromaDB.

Usage :
    python ingest.py
"""

import hashlib
from pathlib import Path

import chromadb
from pypdf import PdfReader
from sentence_transformers import SentenceTransformer
from tqdm import tqdm

import config


def read_pdf(path: Path) -> str:
    reader = PdfReader(str(path))
    return "\n".join(page.extract_text() or "" for page in reader.pages)


def read_text_file(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def load_documents(data_dir: Path) -> list[dict]:
    """Charge tous les fichiers supportés et renvoie [{"source": str, "text": str}, ...]"""
    docs = []
    for path in sorted(data_dir.rglob("*")):
        if path.is_dir():
            continue
        if path.suffix.lower() == ".pdf":
            text = read_pdf(path)
        elif path.suffix.lower() in (".txt", ".md"):
            text = read_text_file(path)
        else:
            continue
        if text.strip():
            docs.append({"source": path.name, "text": text})
    return docs


def chunk_text(text: str, chunk_size: int, overlap: int) -> list[str]:
    """Découpage simple en chunks avec chevauchement."""
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunks.append(text[start:end])
        start += chunk_size - overlap
    return [c.strip() for c in chunks if c.strip()]


def make_chunk_id(source: str, index: int, text: str) -> str:
    h = hashlib.md5(text.encode("utf-8")).hexdigest()[:8]
    return f"{source}-{index}-{h}"


def main():
    config.DATA_DIR.mkdir(exist_ok=True)
    config.DB_DIR.mkdir(exist_ok=True)

    docs = load_documents(config.DATA_DIR)
    if not docs:
        print(f"Aucun document trouvé dans {config.DATA_DIR}.")
        print("Mets des fichiers .pdf, .txt ou .md dedans puis relance ce script.")
        return

    print(f"{len(docs)} document(s) trouvé(s). Chunking...")
    all_chunks, all_ids, all_metadatas = [], [], []
    for doc in docs:
        chunks = chunk_text(doc["text"], config.CHUNK_SIZE, config.CHUNK_OVERLAP)
        for i, chunk in enumerate(chunks):
            all_chunks.append(chunk)
            all_ids.append(make_chunk_id(doc["source"], i, chunk))
            all_metadatas.append({"source": doc["source"], "chunk_index": i})

    print(f"{len(all_chunks)} chunks au total. Calcul des embeddings...")
    model = SentenceTransformer(config.EMBEDDING_MODEL)
    embeddings = model.encode(all_chunks, show_progress_bar=True).tolist()

    client = chromadb.PersistentClient(path=str(config.DB_DIR))
    collection = client.get_or_create_collection(config.COLLECTION_NAME)

    print("Sauvegarde dans ChromaDB...")
    batch_size = 100
    for i in tqdm(range(0, len(all_chunks), batch_size)):
        collection.upsert(
            ids=all_ids[i:i + batch_size],
            embeddings=embeddings[i:i + batch_size],
            documents=all_chunks[i:i + batch_size],
            metadatas=all_metadatas[i:i + batch_size],
        )

    print(f"Terminé. {len(all_chunks)} chunks indexés dans '{config.COLLECTION_NAME}'.")


if __name__ == "__main__":
    main()
